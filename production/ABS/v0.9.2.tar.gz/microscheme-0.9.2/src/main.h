#ifndef _MAIN_H_GUARD
#define _MAIN_H_GUARD

extern int opt_includeonce;

#endif