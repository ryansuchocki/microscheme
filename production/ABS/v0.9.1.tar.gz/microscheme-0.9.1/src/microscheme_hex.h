// Hexified internal microscheme files, build no 673.
#ifndef _MSHEXIFIED_H_GUARD
#define _MSHEXIFIED_H_GUARD

extern unsigned char src_primitives_ms[];
extern unsigned int src_primitives_ms_len;

extern unsigned char src_stdlib_ms[];
extern unsigned int src_stdlib_ms_len;

#endif